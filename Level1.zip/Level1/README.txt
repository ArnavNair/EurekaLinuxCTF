We're here at Level 1!

The flag is hidden in the other file in this folder. Simply open it and use the flag to move onto the next level. 

P.S. Get ready, it's going to get tougher.
